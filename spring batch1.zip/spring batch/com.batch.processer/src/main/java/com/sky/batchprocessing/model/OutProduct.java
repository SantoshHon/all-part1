package com.sky.batchprocessing.model;

public class OutProduct {

	private String name;
	private Double price;
	private double disPrice;
	public OutProduct() {
		// TODO Auto-generated constructor stub
	}
	public OutProduct(String name, Double price, double disPrice) {
		super();
		this.name = name;
		this.price = price;
		this.disPrice = disPrice;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public double getDisPrice() {
		return disPrice;
	}
	public void setDisPrice(double disPrice) {
		this.disPrice = disPrice;
	}
	@Override
	public String toString() {
		return "OutProduct [name=" + name + ", price=" + price + ", disPrice=" + disPrice + "]";
	}
	
}
